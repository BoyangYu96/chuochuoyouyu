# last edit date: 2016/09/24
# author: Forec
# LICENSE
# Copyright (c) 2015-2017, Forec <forec@bupt.edu.cn>

# Permission to use, copy, modify, and/or distribute this code for any
# purpose with or without fee is hereby granted, provided that the above
# copyright notice and this permission notice appear in all copies.

# THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
# WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
# ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
# WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
# ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
# OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

import sys
import time
import argparse
from vchat import Video_Server, Video_Client
from achat import Audio_Server, Audio_Client

# parser = argparse.ArgumentParser()
#
# parser.add_argument('--host', type=str, default='192.168.43.219')
# parser.add_argument('--port', type=int, default=10087)
# parser.add_argument('--noself', type=bool, default=False)
# parser.add_argument('--level', type=int, default=1)
# parser.add_argument('-v', '--version', type=int, default=4)
#
# args = parser.parse_args()
#
# IP = args.host
# PORT = args.port
# VERSION = args.version
# SHOWME = not args.noself
# LEVEL = args.level


class VideoChat():

    def __init__(self):
        self.parser = argparse.ArgumentParser()
        self.parser.add_argument('--host', type=str, default='101.5.140.114')
        self.parser.add_argument('--port', type=int, default=10087)
        self.parser.add_argument('--noself', type=bool, default=False)
        self.parser.add_argument('--level', type=int, default=1)
        self.parser.add_argument('-v', '--version', type=int, default=4)

        self.args = self.parser.parse_args()

        self.IP = self.args.host
        self.PORT = self.args.port
        self.VERSION = self.args.version
        self.SHOWME = not self.args.noself
        self.LEVEL = self.args.level
        self.vclient = Video_Client(self.IP, self.PORT + 2, self.SHOWME, self.LEVEL, self.VERSION)
        self.vserver = Video_Server(self.PORT, self.VERSION)
        self.aclient = Audio_Client(self.IP, self.PORT + 4, self.VERSION)
        self.aserver = Audio_Server(self.PORT + 3, self.VERSION)

    def do_videochat(self):
        self.vclient.start()
        self.vserver.start()
        self.aclient.start()
        self.aserver.start()
        while True:
            time.sleep(1)


# if __name__ == '__main__':
#     vclient = Video_Client(IP, PORT, SHOWME, LEVEL, VERSION)
#     vserver = Video_Server(PORT+2, VERSION)
#     aclient = Audio_Client(IP, PORT+3, VERSION)
#     aserver = Audio_Server(PORT+4, VERSION)
#     vclient.start()
#     vserver.start()
#     aclient.start()
#     aserver.start()
#     while True:
#         time.sleep(1)
#         # if not vserver.isAlive() or not vclient.isAlive():
#         #     print("Video connection lost...")
#         #     sys.exit(0)
#         # if not aserver.isAlive() or not aclient.isAlive():
#         #     print("Audio connection lost...")
#         #     sys.exit(0)