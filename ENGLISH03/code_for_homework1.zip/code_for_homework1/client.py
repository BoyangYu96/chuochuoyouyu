# -*- coding:utf-8 -*-

import wx
import telnetlib
from time import sleep
import _thread as thread
from videomain import VideoChat
import threading

Port = 6666
Server_address = '101.5.138.154'


class MainFrame(wx.Frame):
    """
    主界面
    """
    def __init__(self, parent, id, title, size):
        wx.Frame.__init__(self, parent, id, title)
        self.SetSize(size)
        self.Center()

        titleT = wx.StaticText(self, label="欢迎来到在线学习系统!", pos=(135, 45), size=(120, 30))
        font = wx.Font(25, wx.DEFAULT, wx.NORMAL, wx.BOLD)
        titleT.SetBackgroundColour("White")
        titleT.SetFont(font)


        self.registerButton = wx.Button(self, label = "注册", pos = (245, 155), size = (150, 60))
        self.loginButton = wx.Button(self, label = "登录", pos = (245, 295), size = (150, 60))
        self.quitButton = wx.Button(self, label="退出系统", pos=(540, 15), size=(60, 30))

        self.quitButton.Bind(wx.EVT_BUTTON, self.exit)
        self.loginButton.Bind(wx.EVT_BUTTON, self.login)
        self.registerButton.Bind(wx.EVT_BUTTON, self.register)
        self.Bind(wx.EVT_ERASE_BACKGROUND, self.OnEraseBack)
        self.Show()


    def OnEraseBack(self, event):
        dc = event.GetDC()
        if not dc:
            dc = wx.ClientDC(self)
            rect = self.GetUpdateRegion().GetBox()
            dc.SetClippingRect(rect)
        dc.Clear()
        bmp = wx.Bitmap("background.jpg")
        dc.DrawBitmap(bmp, 0, 0)

    def login(self, event):
        self.Close()
        LoginFrame(None, 2, title="Login", size=(640, 500))

    def register(self, event):
        self.Close()
        RegisterFrame(None, 3, title='Register', size=(640, 500))

    def exit(self, event):
        self.Close()


class RegisterFrame(wx.Frame):
    """
    注册窗口
    """
    def __init__(self, parent, id, title, size):
        # 初始化，添加控件并绑定事件
        wx.Frame.__init__(self, parent, id, title)
        self.SetSize(size)
        self.Center()
        self.userNameLabel = wx.StaticText(self, label = "用户名", pos = (200, 77), size = (45, 30))
        self.userName = wx.TextCtrl(self, pos = (245, 70), size = (150, 30))
        self.pwdLabel = wx.StaticText(self, label = "密码", pos = (200, 127), size = (45, 30))
        self.password = wx.TextCtrl(self, pos = (245, 120), size = (150, 30), style = wx.TE_PASSWORD)
        self.pwd1Label = wx.StaticText(self, label="确认密码", pos=(175, 177), size=(70, 30))
        self.password1 = wx.TextCtrl(self, pos=(245, 170), size=(150, 30), style = wx.TE_PASSWORD)
        self.ageLabel = wx.StaticText(self, label = "年龄", pos = (200, 227), size = (45, 30))
        self.age = wx.TextCtrl(self, pos = (245, 220), size = (150, 30))

        self.userNameLabel.SetBackgroundColour("White")
        self.pwdLabel.SetBackgroundColour("White")
        self.pwd1Label.SetBackgroundColour("White")
        self.ageLabel.SetBackgroundColour("White")



        # 加一个复选框考虑语言问题
        self.backButton = wx.Button(self, label="返回", pos=(15, 15), size=(60, 30))
        self.backButton.Bind(wx.EVT_BUTTON, self.back)
        self.quitButton = wx.Button(self, label="退出系统", pos=(540, 15), size=(60, 30))
        self.quitButton.Bind(wx.EVT_BUTTON, self.exit)
        self.RegisterButton = wx.Button(self, label='注册', pos=(245, 350), size=(150, 30))
        self.RegisterButton.Bind(wx.EVT_BUTTON, self.register)
        self.Bind(wx.EVT_ERASE_BACKGROUND, self.OnEraseBack)
        self.Show()

    def back(self, event):
        self.Close()
        MainFrame(None, id = wx.ID_ANY, title="Online Learning System", size=(640, 500))

    def OnEraseBack(self, event):
        dc = event.GetDC()
        if not dc:
            dc = wx.ClientDC(self)
            rect = self.GetUpdateRegion().GetBox()
            dc.SetClippingRect(rect)
        dc.Clear()
        bmp = wx.Bitmap("background.jpg")
        dc.DrawBitmap(bmp, 0, 0)

    def register(self, event):   # 判定两次密码是否一致，信息写入
        # 登录处理
        try:
            con.open(Server_address, Port, timeout=10)
            response = con.read_some()
            if response != b'Connect Success':
                self.showDialog("错误提示", "连接失败")
                return
            con.write(('register ' + str(self.userName.GetLineText(0)) + ' '
                                   + str(self.password.GetLineText(0)) + ' '
                                   + str(self.password1.GetLineText(0)) + ' '
                                   + str(self.age.GetLineText(0)) + '\n').encode("utf-8"))
            response = con.read_some()

            if response == b'Some Empty':
                self.showDialog("错误提示", "有选项为空! 请填写完整!")
            elif response == b'Username Exist':
                self.showDialog("错误提示", "该用户名已存在!")
            elif response == b'Password Not Same':
                self.showDialog("错误提示", "两次密码输入不一致! 请重新输入!")
            elif response == b'Age Error':
                self.showDialog("错误提示", "所填年龄不在合法范围之内! 请重新输入!")
            else:
                self.showDialog("提示信息", "恭喜注册成功!")
                self.Close()
                MainFrame(None, 5, title='Online Learning System', size=(640, 500))

        except Exception:
            self.showDialog("错误提示", "连接失败")

    def showDialog(self, title, content):
        box = wx.MessageDialog(None, content, title, wx.OK)
        answer = box.ShowModal()
        box.Destroy()

    def exit(self, event):
        self.Close()


class LoginFrame(wx.Frame):
    """
    登录窗口
    """
    def __init__(self, parent, id, title, size):
        # 初始化，添加控件并绑定事件
        wx.Frame.__init__(self, parent, id, title)
        self.SetSize(size)
        self.Center()
        self.userNameLabel = wx.StaticText(self, label = "用户名", pos = (200, 157), size = (45, 30))
        self.userName = wx.TextCtrl(self, pos = (245, 150), size=(150, 30))
        self.pwdLabel = wx.StaticText(self, label = "密码", pos = (200, 207), size = (45, 30))
        self.password = wx.TextCtrl(self, pos = (245, 200), size = (150, 30), style = wx.TE_PASSWORD)
        self.loginButton = wx.Button(self, label = "登录", pos = (245, 270), size = (150, 30))
        self.backButton = wx.Button(self, label="返回", pos=(15, 15), size=(60, 30))
        self.quitButton = wx.Button(self, label="退出系统", pos=(540, 15), size=(60, 30))
        self.quitButton.Bind(wx.EVT_BUTTON, self.exit)
        self.backButton.Bind(wx.EVT_BUTTON, self.back)
        self.loginButton.Bind(wx.EVT_BUTTON, self.login)
        self.Bind(wx.EVT_ERASE_BACKGROUND, self.OnEraseBack)

        self.userNameLabel.SetBackgroundColour("White")
        self.pwdLabel.SetBackgroundColour("White")

        self.Show()

    def OnEraseBack(self, event):
        dc = event.GetDC()
        if not dc:
            dc = wx.ClientDC(self)
            rect = self.GetUpdateRegion().GetBox()
            dc.SetClippingRect(rect)
        dc.Clear()
        bmp = wx.Bitmap("background.jpg")
        dc.DrawBitmap(bmp, 0, 0)

    def login(self, event):
        # 登录处理
        try:
            con.open(Server_address, Port, timeout=10)
            response = con.read_some()
            if response != b'Connect Success':
                self.showDialog("错误提示", "连接失败")
                return
            con.write(('login ' + str(self.userName.GetLineText(0)) + ' '
                                + str(self.password.GetLineText(0)) + '\n').encode("utf-8"))
            response = con.read_some()

            if response == b'UserName or Password Empty':
                self.showDialog("错误提示", "用户名或密码为空!")
            elif response == b'User Login':
                self.showDialog("错误提示", "该用户已登录系统!")
            elif response == b'UserName Not Exist':
                self.showDialog("错误提示", "该用户不存在!")
            elif response == b'Wrong Password':
                self.showDialog("错误提示", "密码错误! 请重新输入!")
            else:
                self.Close()
                UserPanel(None, 4, 'User', (640, 500), str(self.userName.GetLineText(0)))

        except Exception:
            self.showDialog("错误提示", "连接失败")

    def showDialog(self, title, content):
        box = wx.MessageDialog(None, content, title, wx.OK)
        answer = box.ShowModal()
        box.Destroy()

    def back(self, event):
        self.Close()
        MainFrame(None, id=wx.ID_ANY, title="Online Learning System", size=(640, 500))

    def exit(self, event):
        self.Close()


class UserPanel(wx.Frame):
    """
    用户登录后主界面
    """
    def __init__(self, parent, id, title, size, username):
        wx.Frame.__init__(self, parent, id, title)
        self.username = username
        self.SetSize(size)
        self.Center()
        self.infoButton = wx.Button(self, label = "用户信息", pos = (245, 150), size = (150, 60))
        self.listButton = wx.Button(self, label="用户列表", pos=(245, 270), size=(150, 60))
        self.receiveButton = wx.Button(self, label="允许接收聊天请求", pos=(450, 420), size=(120, 30))
        self.quitButton = wx.Button(self, label="退出系统", pos=(540, 15), size=(60, 30))
        self.quitButton.Bind(wx.EVT_BUTTON, self.exit)
        self.infoButton.Bind(wx.EVT_BUTTON, self.getinfo)
        self.listButton.Bind(wx.EVT_BUTTON, self.getlist)
        self.receiveButton.Bind(wx.EVT_BUTTON, self.allow)
        self.Bind(wx.EVT_ERASE_BACKGROUND, self.OnEraseBack)
        self.Show()

        # ChatFrame(None, id=wx.ID_ANY, title="Chat Room", size=(550, 390))

    def OnEraseBack(self, event):
        dc = event.GetDC()
        if not dc:
            dc = wx.ClientDC(self)
            rect = self.GetUpdateRegion().GetBox()
            dc.SetClippingRect(rect)
        dc.Clear()
        bmp = wx.Bitmap("background.jpg")
        dc.DrawBitmap(bmp, 0, 0)

    def getinfo(self, event):
        con.write(('info ' + self.username + '\n').encode("utf-8"))
        res = con.read_some().decode("utf-8").split(' ')
        InfoFrame(None, 7, "User Info", (640, 500), res)

    def getlist(self, event):
        con.write(('list \n').encode("utf-8"))
        res = con.read_until(b'|').decode("utf-8")
        UserList(None, 11, "User List", (640, 500), res)

    def allow(self, event):
        # thread.start_new_thread(self.receive, ())

        if self.is_spec(self.username) == 0:
            self.showDialog("错误提示", "您还不是会员，需要充值后才能执行该操作!")
            return

        response = con.read_some()
        # print(response)

        if response == b'receivew':
            ChatFrame(None, id=wx.ID_ANY, title="Chat Room", size=(550, 390))
            # self.allow1()
        elif response == b'receivev':
            vc = VideoChat()
            vc.do_videochat()

    def is_spec(self, name):
        with open('info.log', 'r') as f:
            info = f.readlines()
            for i in range(len(info)):
                if name == info[i].strip().split(' ')[0]:
                    if info[i].strip().split(' ')[3] == '0':
                        return 0
                    else:
                        return 1

    def exit(self, event):
        self.Close()

    def showDialog(self, title, content):
        box = wx.MessageDialog(None, content, title, wx.OK)
        answer = box.ShowModal()
        box.Destroy()


    # def receive(self):
    #     # 接受服务器的消息
    #     while True:
    #         sleep(0.6)
    #         result = con.read_very_eager()
    #         print("Result:", result)
    #         if result != b'':
    #             # res_cmd = result.slpit(' ')[0]
    #             # res_n = result.split(' ')[1]
    #             # print('res_cmd:', res_cmd)
    #             if result == b'receive':
    #                 con.write(('receivechat \n').encode("utf-8"))
    #                 ChatFrame(None, id=wx.ID_ANY, title="Chat Room", size=(550, 390))



class UserList(wx.Frame):
    def __init__(self, parent, id, title, size, res):
        wx.Frame.__init__(self, parent, id, title)
        self.SetSize(size)
        self.Center()

        user_list = res.strip('|').strip().split('\n')

        self.scroller = wx.ScrolledWindow(self, -1)
        self.scroller.SetScrollbars(0, 1, 0, 160 * len(user_list) + 30)

        titleT = wx.StaticText(self.scroller, label="用户列表", pos=(270, 15), size=(100, 30))
        font = wx.Font(15, wx.DEFAULT, wx.NORMAL, wx.BOLD)
        titleT.SetFont(font)

        for i in range(len(user_list)):
            tinfo = user_list[i].split(' ')
            tname = tinfo[0]
            tage = tinfo[2]
            if tinfo[3] == '0':
                tspec = "否"
            else:
                tspec = "是"

            ypos = (130 + 30) * i + 60

            usrT = wx.StaticText(self.scroller, label="用户名: " + tname, pos = (70, ypos - 5), size=(100, 30))
            ageT = wx.StaticText(self.scroller, label="年龄: " + tage, pos=(120, ypos + 30), size=(100, 30))
            specT = wx.StaticText(self.scroller, label="是否会员: " + tspec, pos=(120, ypos + 65), size=(100, 30))
            font = wx.Font(12, wx.DEFAULT, wx.NORMAL, wx.NORMAL)
            usrT.SetFont(font)
            ageT.SetFont(font)
            specT.SetFont(font)

            # usrT.SetBackgroundColour("White")

            wchatButton = wx.Button(self.scroller, label="和 " + tname + " 文字聊天", pos=(370, ypos + 15), size=(100, 30))
            wchatButton.Bind(wx.EVT_BUTTON, self.wchat)
            vchatButton = wx.Button(self.scroller, label="和 " + tname + " 视频聊天", pos=(370, ypos + 55), size=(100, 30))
            vchatButton.Bind(wx.EVT_BUTTON, self.vchat)

        self.backButton = wx.Button(self.scroller, label="返回", pos=(15, 15), size=(60, 30))
        self.backButton.Bind(wx.EVT_BUTTON, self.back)
        self.Show()


    def wchat(self, event):
        label = event.GetEventObject().GetLabel()
        name = label.split(' ')[1]
        con.write(('wchat ' + name + '\n').encode("utf-8"))
        response = con.read_some()
        # print("res:", response)
        if response == b'not spec':
            self.showDialog("错误提示","您还不是会员，需要充值后才能执行该操作!")
        elif response == b'not online':
            self.showDialog("错误提示", "该用户不在线!")
        elif response == b'other not spec':
            self.showDialog("错误提示", "该用户不是会员，无法与其聊天!")
        else:
            ChatFrame(None, id=wx.ID_ANY, title="Chat Room", size=(550, 390))


    def vchat(self, event):

        label = event.GetEventObject().GetLabel()
        name = label.split(' ')[1]
        con.write(('video ' + name + '\n').encode("utf-8"))
        response = con.read_some()
        # print("res:", response)
        if response == b'not spec':
            self.showDialog("错误提示","您还不是会员，需要充值后才能执行该操作!")
        elif response == b'not online':
            self.showDialog("错误提示", "该用户不在线!")
        elif response == b'other not spec':
            self.showDialog("错误提示", "该用户不是会员，无法与其聊天!")
        elif response == b'sendv':
            vc = VideoChat()
            vc.do_videochat()


    def back(self, event):
        self.Close()

    def showDialog(self, title, content):
        box = wx.MessageDialog(None, content, title, wx.OK)
        answer = box.ShowModal()
        box.Destroy()


class ChatFrame(wx.Frame):
    """
    聊天窗口
    """

    def __init__(self, parent, id, title, size):
        # 初始化，添加控件并绑定事件
        wx.Frame.__init__(self, parent, id, title)
        self.SetSize(size)
        self.Center()
        self.chatFrame = wx.TextCtrl(self, pos=(5, 5), size=(490, 310), style=wx.TE_MULTILINE | wx.TE_READONLY)
        self.message = wx.TextCtrl(self, pos=(5, 320), size=(300, 25))
        self.sendButton = wx.Button(self, label="Send", pos=(310, 320), size=(58, 25))
        self.usersButton = wx.Button(self, label="Users", pos=(373, 320), size=(58, 25))
        self.closeButton = wx.Button(self, label="Close", pos=(436, 320), size=(58, 25))
        # 发送按钮绑定发送消息方法
        self.sendButton.Bind(wx.EVT_BUTTON, self.send)
        # Users按钮绑定获取在线用户数量方法
        self.usersButton.Bind(wx.EVT_BUTTON, self.lookUsers)
        # 关闭按钮绑定关闭方法
        self.closeButton.Bind(wx.EVT_BUTTON, self.close)
        thread.start_new_thread(self.receive, ())
        self.Show()

        print("enter chatframe")

    def send(self, event):
        # 发送消息
        message = str(self.message.GetLineText(0)).strip()
        if message != '':
            con.write(('say ' + message + '\n').encode("utf-8"))
            self.message.Clear()

    def lookUsers(self, event):
        # 查看当前在线用户
        con.write(b'look\n')

    def close(self, event):
        # 关闭窗口
        con.write(b'logout\n')
        # con.close()
        self.Close()

    def receive(self):
        # 接受服务器的消息
        while True:
            sleep(0.6)
            result = con.read_very_eager()
            if result != '':
                self.chatFrame.AppendText(result)


class InfoFrame(wx.Frame):
    def __init__(self, parent, id, title, size, info):
        wx.Frame.__init__(self, parent, id, title)
        self.SetSize(size)
        self.Center()
        self.usrname = info[0]
        self.pwd = info[1]
        self.age = info[2]
        if info[3] == '0':
            self.spec = "否"
        else:
            self.spec = "是"

        self.usrT = wx.StaticText(self, label = "用户名: " + self.usrname, pos = (210, 100), size = (100, 30), style = wx.ALIGN_CENTER)
        self.pwdT = wx.StaticText(self, label = "密码: " + self.pwd, pos=(210, 170), size=(100, 30), style = wx.ALIGN_CENTER)
        self.ageT = wx.StaticText(self, label = "年龄: " + self.age, pos=(210, 240), size=(100, 30), style = wx.ALIGN_CENTER)
        self.specT = wx.StaticText(self, label = "是否会员: " + self.spec, pos=(210, 310), size=(100, 30), style = wx.ALIGN_CENTER)
        font = wx.Font(15, wx.DEFAULT, wx.NORMAL, wx.NORMAL)
        self.usrT.SetFont(font)
        self.pwdT.SetFont(font)
        self.ageT.SetFont(font)
        self.specT.SetFont(font)

        self.usrT.SetBackgroundColour("White")
        self.pwdT.SetBackgroundColour("White")
        self.ageT.SetBackgroundColour("White")
        self.specT.SetBackgroundColour("White")


        self.payButton = wx.Button(self, label="会员充值", pos=(360, 305), size=(60, 30))
        self.payButton.Bind(wx.EVT_BUTTON, self.pay)
        self.backButton = wx.Button(self, label="返回", pos=(285, 395), size=(60, 30))
        self.backButton.Bind(wx.EVT_BUTTON, self.back)
        self.Bind(wx.EVT_ERASE_BACKGROUND, self.OnEraseBack)
        self.Show()

    def pay(self, event):
        payFrame(None, 10, "payment", (300, 300))

    def back(self, event):
        self.Close()

    def OnEraseBack(self, event):
        dc = event.GetDC()
        if not dc:
            dc = wx.ClientDC(self)
            rect = self.GetUpdateRegion().GetBox()
            dc.SetClippingRect(rect)
        dc.Clear()
        bmp = wx.Bitmap("background.jpg")
        dc.DrawBitmap(bmp, 0, 0)


class payFrame(wx.Frame):

    def __init__(self, parent, id, title, size):
        wx.Frame.__init__(self, parent, id, title)
        self.SetSize(size)
        self.Center()
        mypanel = wx.Panel(self, 8, size = size)
        image = wx.Image('pay.png',wx.BITMAP_TYPE_PNG)
        mypic = image.ConvertToBitmap()
        wx.StaticBitmap(mypanel, 9, bitmap = mypic, pos = (95, 60))
        self.backButton = wx.Button(mypanel, label = "返回", pos=(115, 200), size=(60, 30))
        self.backButton.Bind(wx.EVT_BUTTON, self.back)
        self.Show()

    def back(self, event):
        self.Close()

if __name__ == '__main__':
    app = wx.App()
    con = telnetlib.Telnet()
    MainFrame(None, -1, title = "Online Learning System", size = (640, 500))
    app.MainLoop()

# id号已经使用到11