# -*- coding: utf-8 -*-

import asynchat
import asyncore
import time

# 定义端口
PORT = 6666

# 定义结束异常类
class EndSession(Exception):
    pass


class ChatServer(asyncore.dispatcher):
    """
    聊天服务器
    """

    def __init__(self, port):
        asyncore.dispatcher.__init__(self)
        # 创建socket
        self.create_socket()
        # 设置 socket 为可重用
        self.set_reuse_addr()
        # 监听端口
        self.bind(('', port))
        self.listen(5)
        self.users = {}
        self.chat_room = {}
        for i in range(100):
            self.chat_room[i] = ChatRoom(self)
        # self.chat_room = ChatRoom(self)
        self.main_panel = MainRoom(self)
        self.user_panel = UserRoom(self)

    def handle_accept(self):
        conn, addr = self.accept()
        ChatSession(self, conn)


class ChatSession(asynchat.async_chat):
    """
    负责和客户端通信
    """

    def __init__(self, server, sock):
        asynchat.async_chat.__init__(self, sock)
        self.server = server
        self.set_terminator(b'\n')
        self.data = []
        self.name = None
        self.enter(MainRoom(server))

    def enter(self, room):
        # 从当前房间移除自身，然后添加到指定房间
        try:
            cur = self.room
        except AttributeError:
            pass
        else:
            cur.remove(self)
        self.room = room
        room.add(self)

    def collect_incoming_data(self, data):
        # 接收客户端的数据
        self.data.append(data.decode("utf-8"))

    def found_terminator(self):
        # 当客户端的一条数据结束时的处理
        line = ''.join(self.data)
        self.data = []
        try:
            self.room.handle(self, line.encode("utf-8"))
        # 退出聊天室的处理
        except EndSession:
            self.handle_close()

    def handle_close(self):
        # 当 session 关闭时，将进入 LogoutRoom
        asynchat.async_chat.handle_close(self)
        self.enter(quitRoom(self.server))


class CommandHandler:
    """
    命令处理类
    """

    def unknown(self, session, cmd):
        # 响应未知命令
        # 通过 aynchat.async_chat.push 方法发送消息
        session.push(('Unknown command {} \n'.format(cmd)).encode("utf-8"))

    def handle(self, session, line):
        line = line.decode()
        # 命令处理
        if not line.strip():
            return
        parts = line.split(' ', 1)
        cmd = parts[0]
        try:
            line = parts[1].strip()
        except IndexError:
            line = ''
        # 通过协议代码执行相应的方法
        method = getattr(self, 'do_' + cmd, None)
        try:
            method(session, line)
        except TypeError:
            self.unknown(session, cmd)


class Room(CommandHandler):
    """
    包含多个用户的环境，负责基本的命令处理和广播
    """

    def __init__(self, server):
        self.server = server
        self.sessions = []
        self.n_chatroom = 0

    def add(self, session):
        # 一个用户进入房间
        self.sessions.append(session)

    def remove(self, session):
        # 一个用户离开房间
        self.sessions.remove(session)

    def broadcast(self, line):
        # 向所有的用户发送指定消息
        # 使用 asynchat.asyn_chat.push 方法发送数据
        for session in self.sessions:
            session.push(line)

    # def do_logout(self, session, line):
    #     # 退出房间
    #     raise EndSession

    def do_quit(self, session, line):
        raise EndSession


class MainRoom(Room):
    """
    处理登录用户和注册用户
    """

    def add(self, session):
        # 用户连接成功的回应
        Room.add(self, session)
        # 使用 asynchat.asyn_chat.push 方法发送数据
        session.push(b'Connect Success')

    def do_login(self, session, line):
        # 用户登录逻辑
        cmd = line.split(' ')
        if len(cmd) < 2:
            session.push(b'UserName or Password Empty')
            return

        name = cmd[0]
        password = cmd[1]


        if name in self.server.users:
            session.push(b'User Login')
        else:
            rst = self.judge_user(name, password)
            if rst == 0:
                session.push(b'UserName Not Exist')
            elif rst == 1:
                session.push(b'Wrong Password')
            else:
                session.name = name
                session.enter(self.server.user_panel)

    def do_register(self, session, line):
        # 用户注册逻辑
        cmd = line.split(' ')
        if len(cmd) < 4:
            session.push(b'Some Empty')
            return

        name = cmd[0]
        password = cmd[1]
        password1 = cmd[2]
        age = cmd[3]

        if self.Exist_user(name) == True:
            session.push(b'Username Exist')
        elif password != password1:
            session.push(b'Password Not Same')
        elif int(age) < 0 or int(age) > 200:
            session.push(b'Age Error')
        else:
            with open('info.log', 'a') as f:
                info = name + ' ' + password + ' ' + age + ' ' + '0\n'
                # print("info:", info)
                f.write(info)
            session.enter(self.server.main_panel)

    def judge_user(self, name, password):    # 0:no user  1:user wrong pwd  2:right pwd
        with open('info.log', 'r') as f:
            all_info = f.readlines()
            for i in range(len(all_info)):
                all_info[i] = all_info[i].strip('\n')
                cur_name = all_info[i].split(' ')[0]
                if cur_name == name:
                    cur_pwd = all_info[i].split(' ')[1]
                    if password == cur_pwd:
                        f.close()
                        return 2
                    else:
                        f.close()
                        return 1
        return 0

    def Exist_user(self, name):               # True: Username exit
        with open('info.log', 'r') as f:
            all_info = f.readlines()
            for i in range(len(all_info)):
                all_info[i] = all_info[i].strip('\n')
                cur_name = all_info[i].split(' ')[0]
                if cur_name == name:
                    f.close()
                    return True
        return False


class UserRoom(Room):
    """
    处理用户面板上操作
    """

    def add(self, session):
        # 用户连接成功的回应
        Room.add(self, session)
        # 使用 asynchat.asyn_chat.push 方法发送数据
        session.push(b'Connect Success')

    def do_info(self, session, line):
        name = line.strip()
        info = None
        with open('info.log', 'r') as f:
            all_info = f.readlines()
            for i in range(len(all_info)):
                all_info[i] = all_info[i].strip('\n')
                cur_name = all_info[i].split(' ')[0]
                if cur_name == name:
                    info = all_info[i]
                    break
        session.push(info.encode("utf-8"))

    def do_list(self, session, line):
        info_list = None
        msg = ''
        with open('info.log', 'r') as f:
            info_list = f.readlines()

        for i in range(len(info_list)):
            if session.name == info_list[i].split(' ')[0]:
                continue
            msg = msg + info_list[i]
        msg = msg +  '|'
        session.push(msg.encode("utf-8"))

    def do_wchat(self, session, line):
        # print(session.name, " want to chat with ", line)
        # session.enter(self.server.chat_room)

        if self.get_spec(session.name) == 0:
            session.push(b'not spec')
            return

        for other in self.sessions:
            if self.online(line) == False:
                session.push(b'not online')
                return
            elif self.get_spec(line) == 0:
                session.push(b'other not spec')
                return
            else:
                session.enter(self.server.chat_room[self.n_chatroom])
                for other in self.sessions:
                    if other.name == line:
                        other.push(b'receivew')
                        other.enter(self.server.chat_room[self.n_chatroom])


    def do_video(self, session, line):

        if self.get_spec(session.name) == 0:
            session.push(b'not spec')
            return

        for other in self.sessions:
            if self.online(line) == False:
                session.push(b'not online')
                return
            elif self.get_spec(line) == 0:
                session.push(b'other not spec')
                return
            else:
                session.push(b'sendv')
                for other in self.sessions:
                    if other.name == line:
                        other.push(b'receivev')


    def online(self, chatname):
        for other in self.sessions:
            if other.name == chatname:
                return True
        return False

    def get_spec(self, name):
        with open('info.log', 'r') as f:
            infos = f.readlines()
            for i in range(len(infos)):
                if name == infos[i].strip().split(' ')[0]:
                    if infos[i].strip().split(' ')[3] == '0':
                        return 0
                    else:
                        return 1


# class LogoutRoom(Room):
#     """
#     处理退出聊天用户 --- 要改
#     """
#
#     def add(self, session):
#         # 从服务器中移除
#         # try:
#         #     del self.server.users[session.name]
#         # except KeyError:
#         #     pass
#         session.enter(self.server.user_panel)

class quitRoom(Room):
    """
    处理退出用户
    """
    def add(self, session):
        try:
            del self.server.users[session.name]
        except KeyError:
            pass


class ChatRoom(Room):
    """
    聊天用的房间
    """

    def add(self, session):
        # 广播新用户进入
        # session.push(b'Login Success')
        # print(session.name, " enter the room")
        self.server.users[session.name] = session
        Room.add(self, session)
        self.broadcast((session.name + ' has entered the room.\n').encode("utf-8"))

    def remove(self, session):
        # 广播用户离开
        Room.remove(self, session)
        self.broadcast((session.name + ' has left the room.\n').encode("utf-8"))

    def do_say(self, session, line):
        # 客户端发送消息
        print(session.name, ' say: ', line)
        self.broadcast((session.name + ': ' + line + '\n').encode("utf-8"))

    def do_look(self, session, line):
        # 查看在线用户
        session.push(b'Online Users:\n')
        for other in self.sessions:
            session.push((other.name + '\n').encode("utf-8"))

    def do_logout(self, session, line):
        # self.broadcast((session.name + ' has left the room.\n').encode("utf-8"))
        session.enter(self.server.user_panel)


if __name__ == '__main__':

    s = ChatServer(PORT)
    try:
        print("chat serve run at '0.0.0.0:{0}'".format(PORT))
        asyncore.loop()
    except KeyboardInterrupt:
        print("chat server exit")