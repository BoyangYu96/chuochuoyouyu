#!/usr/bin/python
# -*- coding: UTF-8 -*-
import urllib2
import time
import urllib
import json
import hashlib
import base64

IMAGE_PATH='5.jpg'
API_KEY="270558d047c6120ab6c37511f1996bd3"
APPID ="5ba70ad3"

def ocr():
    f = open(IMAGE_PATH, 'rb')
    file_content = f.read()
    base64_image = base64.b64encode(file_content)
    body = urllib.urlencode({'image': base64_image})

    url = 'http://webapi.xfyun.cn/v1/service/v1/ocr/general'
    api_key = API_KEY
    param = {"language": "en", "location": "true"}

    x_appid = APPID
    x_param = base64.b64encode(json.dumps(param).replace(' ', ''))
    x_time = int(int(round(time.time() * 1000)) / 1000)
    x_checksum = hashlib.md5(api_key + str(x_time) + x_param).hexdigest()
    x_header = {'X-Appid': x_appid,
                'X-CurTime': x_time,
                'X-Param': x_param,
                'X-CheckSum': x_checksum}
    req = urllib2.Request(url, body, x_header)
    result = urllib2.urlopen(req)
    result = result.read()

    return result


result = json.loads(ocr())
for r in result['data']['block'][0]['line']:
    for w in r['word']:
        print w['content'],
    print ' '
