import urllib, urllib2, sys
import ssl

host = 'https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id=a74d76b308ac433b9181b02f04bf4520&client_secret=0ca5cfac0fdb4f7cabe4256bbdcea89c'
request = urllib2.Request(host)
request.add_header('Content-Type', 'application/json; charset=UTF-8')
response = urllib2.urlopen(request)
content = response.read()
if (content):
    print(content)