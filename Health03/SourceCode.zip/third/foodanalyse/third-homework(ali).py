#!/usr/bin/python
# -*- coding: UTF-8 -*-
import urllib, urllib2, sys
import ssl
import json
import base64

IMAGE_PATH='cankao.jpg'

food={
  "Gai":{"name":u'钙',"day":"mg","child":[[600,1200],[1500,2000]],"teenager":[[1000,1000],[2000,2000]],"man":[[800,800],[2000,2000]],"oldman":[[1000,1000],[2000,2000]],"mom":[200,0],"suggest":"","less":""},
  "A_m":{"name":u'维生素A',"day":"ugRAE","child":[[310,670],[700,2100]],"teenager":[[820,820],[2700,2700]],"man":[[800,800],[3000,3000]],"oldman":[[800,800],[3000,3000]],"mom":[0,0],"suggest":"","less":""},
  "A_w":{"name":u'维生素A',"day":"ugRAE","child":[[310,630],[700,2100]],"teenager":[[630,630],[2700,2700]],"man":[[700,700],[3000,3000]],"oldman":[[700,700],[3000,3000]],"mom":[70,0],"suggest":"","less":""},
  "B1_m":{"name":u'维生素B1',"day":"mg","child":[[0.6,1.3],[9999,9999]],"teenager":[[1.6,1.6],[9999,9999]],"man":[[1.4,1.4],[9999,9999]],"oldman":[[1.4,1.4],[9999,9999]],"mom":[0,0],"suggest":"","less":""},
  "B1_w":{"name":u'维生素B1',"day":"mg","child":[[0.6,1.1],[9999,9999]],"teenager":[[1.3,1.3],[9999,9999]],"man":[[1.2,1.2],[9999,9999]],"oldman":[[1.2,1.2],[9999,9999]],"mom":[0.3,0],"suggest":"","less":""},
  "B2_m":{"name":u'维生素B2',"day":"mg","child":[[0.6,1.3],[9999,9999]],"teenager":[[1.5,1.5],[9999,9999]],"man":[[1.4,1.4],[9999,9999]],"oldman":[[1.4,1.4],[9999,9999]],"mom":[0,0],"suggest":"","less":""},
  "B2_w":{"name":u'维生素B2',"day":"mg","child":[[0.6,1.1],[9999,9999]],"teenager":[[1.2,1.2],[9999,9999]],"man":[[1.2,1.2],[9999,9999]],"oldman":[[1.2,1.2],[9999,9999]],"mom":[0.3,0],"suggest":"","less":""},
  "B6":{"name":u'维生素B6',"day":"mg","child":[[0.6,1.3],[20,45]],"teenager":[[1.4,1.4],[55,55]],"man":[[1.4,1.4],[60,60]],"oldman":[[1.4,1.4],[60,60]],"mom":[0.8,0],"suggest":"","less":""},
  "B12":{"name":u'维生素B12',"day":"ug","child":[[1.0,2.1],[9999,9999]],"teenager":[[2.4,2.4],[9999,9999]],"man":[[2.4,2.4],[9999,9999]],"oldman":[[2.4,2.4],[9999,9999]],"mom":[0.5,0],"suggest":"","less":""},
  "C":{"name":u'维生素C',"day":"mg","child":[[40,90],[400,1400]],"teenager":[[100,100],[1800,1800]],"man":[[100,100],[2000,2000]],"oldman":[[100,100],[2000,2000]],"mom":[15,0],"suggest":"","less":""},
  "D":{"name":u'维生素D',"day":"ug","child":[[10,10],[20,50]],"teenager":[[10,10],[50,50]],"man":[[10,10],[50,50]],"oldman":[[10,15],[50,50]],"mom":[0,0],"suggest":"","less":""},
  "E":{"name":u'维生素E',"day":"ug","child":[[6,13],[150,500]],"teenager":[[14,14],[600,700]],"man":[[14,14],[700,700]],"oldman":[[14,14],[700,700]],"mom":[0,0],"suggest":"","less":""},
  "Leaf":{"name":u'叶酸',"day":"ug","child":[[160,350],[300,800]],"teenager":[[400,400],[900,900]],"man":[[400,400],[1000,1000]],"oldman":[[400,400],[1000,1000]],"mom":[200,0],"suggest":"","less":""},
  "Iron_m":{"name":u'铁',"day":"mg","child":[[9,15],[25,40]],"teenager":[[16,16],[40,40]],"man":[[12,12],[42,42]],"oldman":[[12,12],[42,42]],"mom":[0,0],"suggest":"","less":""},
  "Iron_w":{"name":u'铁',"day":"mg","child":[[9,18],[25,40]],"teenager":[[18,18],[40,40]],"man":[[20,20],[42,42]],"oldman":[[12,12],[42,42]],"mom":[9,0],"suggest":"","less":""},
  "Mei":{"name":u'镁',"day":"mg","child":[[140,300],[9999,9999]],"teenager":[[320,320],[9999,9999]],"man":[[330,330],[9999,9999]],"oldman":[[310,330],[9999,9999]],"mom":[40,0],"suggest":"","less":""},
  "Xin_m":{"name":u'锌',"day":"mg","child":[[4,10],[8,28]],"teenager":[[11.5,11.5],[35,35]],"man":[[12.5,12.5],[40,40]],"oldman":[[12.5,12.5],[40,40]],"mom":[0,0],"suggest":"","less":""},
  "Xin_w":{"name":u'锌',"day":"mg","child":[[4,9],[8,28]],"teenager":[[8.5,8.5],[35,35]],"man":[[7.5,7.5],[40,40]],"oldman":[[7.5,7.5],[40,40]],"mom":[2,0],"suggest":"","less":""},
  "Lin":{"name":u'磷',"day":"mg","child":[[300,640],[9999,9999]],"teenager":[[710,710],[9999,9999]],"man":[[720,720],[3500,3500]],"oldman":[[670,720],[3000,3500]],"mom":[0,0],"suggest":"","less":""},
  "Xi":{"name":u'硒',"day":"ug","child":[[25,55],[100,300]],"teenager":[[60,60],[350,350]],"man":[[60,60],[400,400]],"oldman":[[60,60],[400,400]],"mom":[5,0],"suggest":"","less":""}
}

def ocr():
    f = open(IMAGE_PATH, 'rb')
    file_content = f.read()
    base64_image = base64.b64encode(file_content)

    host = 'https://ocrapi-ugc.taobao.com'
    path = '/ocrservice/ugc'
    method = 'POST'
    appcode = 'b7450899c4294c43b0b578a0f4f781bc'
    querys = ''
    bodys = {}
    url = host + path


    post_data = json.dumps({'img':base64_image,'prob':"false"})
    request = urllib2.Request(url, post_data)
    request.add_header('Authorization', 'APPCODE ' + appcode)
    request.add_header('Content-Type', 'application/json; charset=UTF-8')
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    response = urllib2.urlopen(request, context=ctx)
    content = response.read()
    if (content):
        return content

result = json.loads(ocr())
for r in result['prism_wordsInfo']:
    print r['word']