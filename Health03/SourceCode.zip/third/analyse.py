#!C:\Python27\python.exe
# coding: UTF-8
print("Content-type:text/html\n")
import re
import urllib2, urllib, cookielib, json,time
from hashlib import md5
import sys
import cgi
import cgitb
import json
import sys
import ssl
reload(sys)
sys.setdefaultencoding('utf-8')

IMAGE_PATH='http://jlu-jiqu.s1.natapp.cc/third/foodimage/4.jpg'

print "<!DOCTYPE html><html><head><meta charset=\"utf-8\">"

food_m={
   "Ener":{"name":u'能量',"day":"kcal","child":[[1100,2000],[9999,9999]],"teenager":[[2000,2900],[9999,9999]],"man":[[2400,3200],[9999,9999]],"oldman":[[2200,2300],[9999,9999]],"mom":[200,0],"suggest":"","less":""},
    "C3H5":{"name":u'脂肪',"day":"g","child":[[25,25],[50,50]],"teenager":[[50,50],[75,75]],"man":[[60,60],[80,80]],"oldman":[[55,55],[60,60]],"mom":[0,0],"suggest":"","less":""},
    "Protein":{"name":u'蛋白质',"day":"g","child":[[35,65],[9999,9999]],"teenager":[[65,85],[9999,9999]],"man":[[75,90],[9999,9999]],"oldman":[[75,75],[9999,9999]],"mom":[20,0],"suggest":"","less":""},
  "Gai":{"name":u'钙',"day":"mg","child":[[600,1200],[1500,2000]],"teenager":[[1000,1000],[2000,2000]],"man":[[800,800],[2000,2000]],"oldman":[[1000,1000],[2000,2000]],"mom":[200,0],"suggest":"","less":""},
  "A":{"name":u'维生素A',"day":"ugRAE","child":[[310,670],[700,2100]],"teenager":[[820,820],[2700,2700]],"man":[[800,800],[3000,3000]],"oldman":[[800,800],[3000,3000]],"mom":[0,0],"suggest":"","less":""},
  "B1":{"name":u'维生素B1',"day":"mg","child":[[0.6,1.3],[9999,9999]],"teenager":[[1.6,1.6],[9999,9999]],"man":[[1.4,1.4],[9999,9999]],"oldman":[[1.4,1.4],[9999,9999]],"mom":[0,0],"suggest":"","less":""},
  "B2":{"name":u'维生素B2',"day":"mg","child":[[0.6,1.3],[9999,9999]],"teenager":[[1.5,1.5],[9999,9999]],"man":[[1.4,1.4],[9999,9999]],"oldman":[[1.4,1.4],[9999,9999]],"mom":[0,0],"suggest":"","less":""},
  "B6":{"name":u'维生素B6',"day":"mg","child":[[0.6,1.3],[20,45]],"teenager":[[1.4,1.4],[55,55]],"man":[[1.4,1.4],[60,60]],"oldman":[[1.4,1.4],[60,60]],"mom":[0.8,0],"suggest":"","less":""},
  "B12":{"name":u'维生素B12',"day":"ug","child":[[1.0,2.1],[9999,9999]],"teenager":[[2.4,2.4],[9999,9999]],"man":[[2.4,2.4],[9999,9999]],"oldman":[[2.4,2.4],[9999,9999]],"mom":[0.5,0],"suggest":"","less":""},
  "C":{"name":u'维生素C',"day":"mg","child":[[40,90],[400,1400]],"teenager":[[100,100],[1800,1800]],"man":[[100,100],[2000,2000]],"oldman":[[100,100],[2000,2000]],"mom":[15,0],"suggest":"","less":""},
  "D":{"name":u'维生素D',"day":"ug","child":[[10,10],[20,50]],"teenager":[[10,10],[50,50]],"man":[[10,10],[50,50]],"oldman":[[10,15],[50,50]],"mom":[0,0],"suggest":"","less":""},
  "E":{"name":u'维生素E',"day":"ug","child":[[6,13],[150,500]],"teenager":[[14,14],[600,700]],"man":[[14,14],[700,700]],"oldman":[[14,14],[700,700]],"mom":[0,0],"suggest":"","less":""},
  "Leaf":{"name":u'叶酸',"day":"ug","child":[[160,350],[300,800]],"teenager":[[400,400],[900,900]],"man":[[400,400],[1000,1000]],"oldman":[[400,400],[1000,1000]],"mom":[200,0],"suggest":"","less":""},
  "Iron":{"name":u'铁',"day":"mg","child":[[9,15],[25,40]],"teenager":[[16,16],[40,40]],"man":[[12,12],[42,42]],"oldman":[[12,12],[42,42]],"mom":[0,0],"suggest":"","less":""},
  "Mei":{"name":u'镁',"day":"mg","child":[[140,300],[9999,9999]],"teenager":[[320,320],[9999,9999]],"man":[[330,330],[9999,9999]],"oldman":[[310,330],[9999,9999]],"mom":[40,0],"suggest":"","less":""},
  "Xin":{"name":u'锌',"day":"mg","child":[[4,10],[8,28]],"teenager":[[11.5,11.5],[35,35]],"man":[[12.5,12.5],[40,40]],"oldman":[[12.5,12.5],[40,40]],"mom":[0,0],"suggest":"","less":""},
  "Lin":{"name":u'磷',"day":"mg","child":[[300,640],[9999,9999]],"teenager":[[710,710],[9999,9999]],"man":[[720,720],[3500,3500]],"oldman":[[670,720],[3000,3500]],"mom":[0,0],"suggest":"","less":""},
  "Xi":{"name":u'硒',"day":"ug","child":[[25,55],[100,300]],"teenager":[[60,60],[350,350]],"man":[[60,60],[400,400]],"oldman":[[60,60],[400,400]],"mom":[5,0],"suggest":"","less":""}
}
food_w={
"Ener":{"name":u'能量',"day":"kcal","child":[[1050,1900],[9999,9999]],"teenager":[[2000,2400],[9999,9999]],"man":[[2100,2700],[9999,9999]],"oldman":[[1900,2200],[9999,9999]],"mom":[200,0],"suggest":"","less":""},
"C3H5":{"name":u'脂肪',"day":"g","child":[[25,25],[50,50]],"teenager":[[50,50],[60,60]],"man":[[60,60],[70,70]],"oldman":[[45,45],[55,55]],"mom":[0,0],"suggest":"","less":""},
"Protein":{"name":u'蛋白质',"day":"g","child":[[35,65],[9999,9999]],"teenager":[[65,80],[9999,9999]],"man":[[65,80],[9999,9999]],"oldman":[[65,65],[9999,9999]],"mom":[20,0],"suggest":"","less":""},
  "Gai":{"name":u'钙',"day":"mg","child":[[600,1200],[1500,2000]],"teenager":[[1000,1000],[2000,2000]],"man":[[800,800],[2000,2000]],"oldman":[[1000,1000],[2000,2000]],"mom":[200,0],"suggest":"","less":""},
  "A":{"name":u'维生素A',"day":"ugRAE","child":[[310,630],[700,2100]],"teenager":[[630,630],[2700,2700]],"man":[[700,700],[3000,3000]],"oldman":[[700,700],[3000,3000]],"mom":[70,0],"suggest":"","less":""},
  "B1":{"name":u'维生素B1',"day":"mg","child":[[0.6,1.1],[9999,9999]],"teenager":[[1.3,1.3],[9999,9999]],"man":[[1.2,1.2],[9999,9999]],"oldman":[[1.2,1.2],[9999,9999]],"mom":[0.3,0],"suggest":"","less":""},
  "B2":{"name":u'维生素B2',"day":"mg","child":[[0.6,1.1],[9999,9999]],"teenager":[[1.2,1.2],[9999,9999]],"man":[[1.2,1.2],[9999,9999]],"oldman":[[1.2,1.2],[9999,9999]],"mom":[0.3,0],"suggest":"","less":""},
  "B6":{"name":u'维生素B6',"day":"mg","child":[[0.6,1.3],[20,45]],"teenager":[[1.4,1.4],[55,55]],"man":[[1.4,1.4],[60,60]],"oldman":[[1.4,1.4],[60,60]],"mom":[0.8,0],"suggest":"","less":""},
  "B12":{"name":u'维生素B12',"day":"ug","child":[[1.0,2.1],[9999,9999]],"teenager":[[2.4,2.4],[9999,9999]],"man":[[2.4,2.4],[9999,9999]],"oldman":[[2.4,2.4],[9999,9999]],"mom":[0.5,0],"suggest":"","less":""},
  "C":{"name":u'维生素C',"day":"mg","child":[[40,90],[400,1400]],"teenager":[[100,100],[1800,1800]],"man":[[100,100],[2000,2000]],"oldman":[[100,100],[2000,2000]],"mom":[15,0],"suggest":"","less":""},
  "D":{"name":u'维生素D',"day":"ug","child":[[10,10],[20,50]],"teenager":[[10,10],[50,50]],"man":[[10,10],[50,50]],"oldman":[[10,15],[50,50]],"mom":[0,0],"suggest":"","less":""},
  "E":{"name":u'维生素E',"day":"ug","child":[[6,13],[150,500]],"teenager":[[14,14],[600,700]],"man":[[14,14],[700,700]],"oldman":[[14,14],[700,700]],"mom":[0,0],"suggest":"","less":""},
  "Leaf":{"name":u'叶酸',"day":"ug","child":[[160,350],[300,800]],"teenager":[[400,400],[900,900]],"man":[[400,400],[1000,1000]],"oldman":[[400,400],[1000,1000]],"mom":[200,0],"suggest":"","less":""},
  "Iron":{"name":u'铁',"day":"mg","child":[[9,18],[25,40]],"teenager":[[18,18],[40,40]],"man":[[20,20],[42,42]],"oldman":[[12,12],[42,42]],"mom":[9,0],"suggest":"","less":""},
  "Mei":{"name":u'镁',"day":"mg","child":[[140,300],[9999,9999]],"teenager":[[320,320],[9999,9999]],"man":[[330,330],[9999,9999]],"oldman":[[310,330],[9999,9999]],"mom":[40,0],"suggest":"","less":""},
  "Xin":{"name":u'锌',"day":"mg","child":[[4,9],[8,28]],"teenager":[[8.5,8.5],[35,35]],"man":[[7.5,7.5],[40,40]],"oldman":[[7.5,7.5],[40,40]],"mom":[2,0],"suggest":"","less":""},
  "Lin":{"name":u'磷',"day":"mg","child":[[300,640],[9999,9999]],"teenager":[[710,710],[9999,9999]],"man":[[720,720],[3500,3500]],"oldman":[[670,720],[3000,3500]],"mom":[0,0],"suggest":"","less":""},
  "Xi":{"name":u'硒',"day":"ug","child":[[25,55],[100,300]],"teenager":[[60,60],[350,350]],"man":[[60,60],[400,400]],"oldman":[[60,60],[400,400]],"mom":[5,0],"suggest":"","less":""}
}
food_order=["Ener","C3H5","Protein","Gai","Iron","Xin","Xi","A","B1","B2","B6","B12","C","D","E","Leaf","Mei","Lin"]
this_food={"Ener":"/","C3H5":"/","Protein":"/","Gai":"/","Iron":"/","Xin":"/","Xi":"/","A":"/","B1":"/","B2":"/","B6":"/","B12":"/","C":"/","D":"/","E":"/","Leaf":"/","Mei":"/","Lin":"/"}

def ocr(base64_image):
    host = 'https://ocrapi-ugc.taobao.com'
    path = '/ocrservice/ugc'
    method = 'POST'
    appcode = 'b7450899c4294c43b0b578a0f4f781bc'
    querys = ''
    bodys = {}
    url = host + path

    post_data = json.dumps({'img':base64_image,'prob':"false"})
    request = urllib2.Request(url, post_data)
    request.add_header('Authorization', 'APPCODE ' + appcode)
    request.add_header('Content-Type', 'application/json; charset=UTF-8')
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    response = urllib2.urlopen(request, context=ctx)
    content = response.read()
    if (content):
        return content




name = '万家兵'
sex = 1
age = 18
mom = 0
imgpath=''
cgitb.enable()
form = cgi.FieldStorage()  # parse form data


if not 'user' in form:
    print('<h1>咋回事啊？大兄弟？你是不知道你名字还是咋滴？咋忘填了了呢？</h1>')
    sys.exit()
else:
   name = cgi.escape(form['user'].value)
if not 'age' in form:
    print('<h1>大兄弟？你今年几岁啊？数数呗，咋忘填了了呢？</h1>')
    sys.exit()
else:
    age = int(cgi.escape(form['age'].value))
if not 'sex' in form:
    print('<h1>你啥性别？男的女的？</h1>')
    sys.exit()
else:
    sex = int(cgi.escape(form['sex'].value))
if not 'mom' in form:
    print('<h1>怀没怀孕不知道啊?孩子是谁的你知不知道？</h1>')
    sys.exit()
else:
    mom = int(cgi.escape(form['mom'].value))

if not 'img' in form:
    print('<h1>伙计，你今天吃啥忘记传了？不给我看看你吃啥咋给你分析？</h1>')
    sys.exit()
else:
    imgpath = cgi.escape(form['img'].value)


print "<title>食品营养素个性化分析结果</title><style type=\"text/css\">body{font-family:arial;}","table{border:1px solid#ccc;width:80%;margin:0;padding:0;border-collapse:collapse;border-spacing:0;margin:0 auto;}","table tr{border:1px solid#ddd;padding:5px;}","table th,table td{padding:10px;text-align:center;}","table th{text-transform:uppercase;font-size:14px;letter-spacing:1px;}@media screen and(max-width:600px){table{border:0;}","table thead{display:none;}"," table tr{margin-bottom:10px;display:block;border-bottom:2px solid #ddd;}","table td{display:block;text-align:right;font-size:13px;border-bottom:1px dotted#ccc;}","table td:last-child{border-bottom:0;}","table td:before{content:attr(data-label);float:left;text-transform:uppercase;font-weight:bold;}}.note{max-width:80%;margin:0 auto;}</style></head>"
print "<body>",

age_rank = "none"
person_type=''

result = json.loads(ocr(imgpath))

for r in range(0,len(result['prism_wordsInfo'])):
    for f in food_order:
        if (food_w[f]['name']  in result['prism_wordsInfo'][r]['word']):
            this_food[f] = result['prism_wordsInfo'][r + 1]['word']

if( age>=1 and age<=13):
    age_rank = 'child'
    person_type = u'儿童'
elif (age>=14 and age<=17):
    age_rank = 'teenager'
    person_type = u'少年'
elif (age>=18 and age<=49):
    age_rank = 'man'
    person_type = u'成人'
elif (age>=50 and age<=150):
    age_rank = 'oldman'
    person_type = u'老人'
else:
    print('<h1>Age is error!</h1>')
    sys.exit()
sex_type=""
food={}
if (sex==1):
    food=food_m
    sex_type = u"男士"
elif(sex==0):
    food=food_w
    sex_type = u"女士"
else:
    print('<h1>咋回事啊，性别有问题？忘记选择了么？</h1>')
    sys.exit()

if(sex==1 and mom==1):
    print('<h1>别搞事啊，兄弟，你一个大男人怎么可能怀孕啊？喝假酒了吧？</h1>')
    sys.exit()

if(mom==1):
    person_type="孕妇"
if(mom==-1):
    print('<h1>怀没怀孕不知道啊?孩子是谁的你知不知道？</h1>')
    sys.exit()

print "<div class=\"note\"><h1>"+name+sex_type+"，您好！</h1><p>经过我们的分析，您现在处于“"+person_type+"”阶段，以下是该食品营养成分分析结果和专为您定制的个人饮食建议，请查看：</p><p>这是你所提供的食品成分表：</p></div><div class=\"note\"><img style=\"width:100%\"  src=\""+imgpath+"\"></div><table><thead><tr><th>营养素名称</th><th>该食品营养素含量</th><th>每日健康摄入量</th><th>每日最多摄入量</th></tr></thead><tbody>"

for j in range(0,15):
    f=food_order[j]
    print "<tr><td data-label=\"\">",
    print str(food[f]['name']),
    print "<td data-label=\"\">"+this_food[f]+"</td>"
    if(mom==1):
        for i in range(0, 2):
            if food[f][age_rank][i][0] == 9999:
                print "<td data-label=\"\">" + '/' + "</td>",
                break
            if food[f][age_rank][i][0] == food[f][age_rank][i][1]:
                print "<td data-label=\"\">" + str(food[f][age_rank][i][0]+food[f]['mom'][0]) +str(food[f]['day'])+"</td>",
            else:
                print "<td data-label=\"\">" + str(food[f][age_rank][i][0]+food[f]['mom'][0]) +str(food[f]['day'])+"-" + str(
                    food[f][age_rank][i][1]+food[f]['mom'][1])+str(food[f]['day'])+ "</td>",
        print "</tr>",
    else:
        for i in range(0,2):
            if food[f][age_rank][i][0]==9999:
                print "<td data-label=\"\">"+'/'+"</td>",
                break
            if food[f][age_rank][i][0]==food[f][age_rank][i][1]:
                print "<td data-label=\"\">"+str(food[f][age_rank][i][0])+str(food[f]['day'])+"</td>",
            else:
                print "<td data-label=\"\">"+str(food[f][age_rank][i][0])+str(food[f]['day'])+"-"+str(food[f][age_rank][i][1])+str(food[f]['day'])+"</td>",
        print "</tr>",
print "</tbody></table></body></html>"
